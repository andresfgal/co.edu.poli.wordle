package co.edu.poli.wordle.controlador;

import co.edu.poli.wordle.vista.Frame;

public class Main {

	public static void main(String[] args) 
	{
		
		new Frame(0);
		
	}
}
