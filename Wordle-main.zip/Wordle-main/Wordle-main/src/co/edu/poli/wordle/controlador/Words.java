package co.edu.poli.wordle.controlador;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.*;


import java.util.Random;

import co.edu.poli.wordle.vista.Frame;

public class Words
{
	int count;
	int position;
	
	Random rand;
	
	File words;
	FileReader fr;
	BufferedReader br;
	
	
	String[] toGetWord= {
			"ARBOL",
			"CASAS",
			"MICRO",
			"RATON",
			"PERRO",
			"VASOS",
			"ABRIR",
			"ABREN",
			"CAZAR",
	};
	
	public String getWord()
	{
		rand=new Random();
		String word=(toGetWord[rand.nextInt(toGetWord.length)]).toLowerCase();
		return word;
	}
	public boolean wordExists(String word)
	{
		Frame f = new Frame(5);
		JButton[][] buttons1 = f.buttons ;
		return true;
	}
	
	
}