package co.edu.poli.wordle.dao;

import java.sql.SQLException;

import co.edu.poli.wordle.modelo.palabras;

public interface IPalabras {

	//INTERFACE DAO IPALABRA
	
	 public palabras getPalabra()
		        throws SQLException;
}
