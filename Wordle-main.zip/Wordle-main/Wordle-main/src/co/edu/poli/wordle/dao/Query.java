package co.edu.poli.wordle.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import co.edu.poli.wordle.modelo.palabras;
  



public class Query
implements IPalabras{
	 static Connection con
     = DatabaseConnection.getConnection();
	 @Override
	    public palabras getPalabra()
	        throws SQLException
	    {
		 
		 int id =1;
	        String query
	            = "select * from palabras where id=?";
	        PreparedStatement ps
	            = con.prepareStatement(query);
	  
	        
	        ps.setInt(1, id);
	        palabras pal = new palabras();
	        ResultSet rs = ps.executeQuery();
	        boolean check = false;
	  
	        while (rs.next()) {
	            check = true;
	            pal.setPal_id(rs.getInt("id"));
	            pal.setPalWordle(rs.getString("PALWORDLE"));	           
	        }
	  
	        if (check == true) {
	            return pal;
	        }
	        else
	            return null;
	    }
	
	
		
	
}