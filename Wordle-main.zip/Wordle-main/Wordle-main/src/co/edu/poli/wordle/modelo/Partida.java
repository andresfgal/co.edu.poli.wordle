package co.edu.poli.wordle.modelo;
import co.edu.poli.wordle.vista.Frame;

import java.sql.SQLException;

import co.edu.poli.wordle.dao.Query;

public class Partida 
{
	boolean checked[];
	boolean correct[];
	private Query query = new Query();
	
	private String intento;
	
	public boolean validar() throws SQLException {
	
		String palwordle =query.getPalabra().PALWORDLE;
		return intento.equals(palwordle);
		
	}

	
	public boolean validarLetra(int n) {
		return n >=65 && n <=90;
	}
	
	public String getIntento() {
		return intento;
	}

	public void setIntento(String intento) {
		this.intento = intento;
	}
	
	
	public void checkWord(String toBeChecked)
	{	
		checked=new boolean[5];
		correct=new boolean[5];
		int[] frequency=new int[5];	
		for(int i=0; i<5; i++)
		{
			checked[i]=false; 
			correct[i]=false;
			frequency[i]=0; 
		}
		
	}

}
