package co.edu.poli.wordle.modelo;

public class palabras {
	String PALWORDLE;
	int id;
	public palabras() {}
	public palabras(String PALWORDLE,int id) {
		this.PALWORDLE = PALWORDLE;
		this.id=id;
	}
	
    public String getPalWordle()
    {
        return PALWORDLE;
    }
  
    public void setPalWordle(String PALWORDLE)
    {
        this.PALWORDLE = PALWORDLE;
    }
    
    public int getPal_id()
    {
        return id;
    }
  
    public void setPal_id(int id)
    {
        this.id = id;
    }
    
    @Override
    public String toString()
    {
        return "palabras [id=" + id + ", PALWORDLE=" + PALWORDLE + "]";
    }
    
}
