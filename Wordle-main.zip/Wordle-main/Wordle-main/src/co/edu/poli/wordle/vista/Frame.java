package co.edu.poli.wordle.vista;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;

import co.edu.poli.wordle.modelo.Partida;


@SuppressWarnings("serial")
public class Frame extends JFrame implements ActionListener, KeyListener
{
	
	
	// DEFINICION TAMA�O DE LA MATRIZ
	
	public JButton buttons[][]=new JButton[6][5];
	JButton resetButton;
	JButton instructionsButton;
	
	JLabel label;	
	
	
	JPanel buttonsPanel=new JPanel();
	JPanel lowerButtons=new JPanel();
	
	boolean canContinue;
	
	Partida P;
	boolean gameOver;
	 
	int intento;
	int letra;
	
		Partida P1 = new Partida();
	
	public Frame(int points)
	
	
	{
		
		P = new Partida(); 
		
		

		intento=0;
		letra=0;
		canContinue=true;
		
		this.setLayout(new BorderLayout());
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setSize(500,600);
		
		label=new JLabel();
		label.setHorizontalAlignment(JLabel.CENTER);				
		label.setOpaque(true);				
	
		
		//BOTON REINICIAR
		
		resetButton=new JButton();		
		resetButton.setText("REINICIAR");
		resetButton.setFocusable(false);
		resetButton.addActionListener(this);
		
		//BOTON INSTRUCCIONES
		
		instructionsButton=new JButton();		
		instructionsButton.setText("INSTRUCCIONES");
		instructionsButton.setFocusable(false);
		instructionsButton.addActionListener(this);		
		
		//VISIBILIDAD DE LOS BOTONES
		
		buttonsPanel.setVisible(true);
		buttonsPanel.setLayout(new GridLayout(6,5));
		
		lowerButtons.setVisible(true);
		lowerButtons.setLayout(new GridLayout(1,2));
		lowerButtons.add(resetButton);
		lowerButtons.add(instructionsButton);
		
		for(int i=0; i<buttons.length; i++)
		{
			for(int j=0; j<buttons[0].length; j++)
			{
				buttons[i][j]=new JButton();
				buttons[i][j].setBackground(Color.WHITE);
				buttons[i][j].setEnabled(false);				
				buttonsPanel.add(buttons[i][j]);
			}
		}
		
		this.add(lowerButtons,BorderLayout.SOUTH);
		this.add(label, BorderLayout.NORTH);		
		this.getContentPane().setBackground(Color.WHITE);
		this.add(buttonsPanel);
		this.addKeyListener(this);
		this.setFocusable(true);
		this.setTitle("WORDLE POLI");
		this.repaint();
		this.revalidate(); 
		this.setLocationRelativeTo(null);
	}	
	
	public void keyTyped(KeyEvent e) 
	{			
		
	}
	
	
	//METODO QUE VALIDA LAS PALABRAS
	
	public void keyPressed(KeyEvent e) 
	{
		if(!gameOver)
		{
			int code=e.getKeyCode();
			if(P.validarLetra(code))
			{
				if(canContinue)
				{
					if(letra<5)
					{
						buttons[intento][letra].setText(String.valueOf((char)code));
						letra++;
					}
					else 
						canContinue=false;
				}
			}
			else if(code==10) 
			{
				if(intento<6)
				{
					if(letra==5)
					{
						String wordTyped="";
						for(int i=0; i<5; i++)
							wordTyped=wordTyped+buttons[intento][i].getText();
						
							System.out.println(wordTyped);
							P.setIntento(wordTyped);
							
							//MENSAJES DE ERROR
							
							try {
								if(P.validar())
								{
								JOptionPane.showMessageDialog(this,"HAS GANADO");
								}
								else {
									JOptionPane.showMessageDialog(this,"La palabra NO esta en la lista");
								}
								
							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								JOptionPane.showMessageDialog(this,"La palabra NO esta en la lista");
							}
							letra=0;
							intento++;
							canContinue=true;
					
					}
					else 
					{
						label.setForeground(Color.RED);
						label.setText("La palabra debe tener 5 letras");
					}
				}
			}
			else if(code==8) 
			{
				if(letra>0)
				{
					letra--;
					canContinue=true;
					buttons[intento][letra].setText("");
				}
			}
		}
	}
	
	public void keyReleased(KeyEvent e)
	{
		
	}
	
	//EVENTO MENSAJE DE INSTRUCCIONES
	
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==resetButton)
		{
			this.dispose();
			new Frame(0);
		}
		if(e.getSource()==instructionsButton)
		{
			JOptionPane.showMessageDialog(this,
				    "	    				C�mo jugar\r\n"
				    + "\r\n"
				    + "Adivina la palabra oculta en seis intentos.\r\n"
				    + "Cada intento debe ser una palabra v�lida de 5 letras.\r\n"
				    + "Despu�s de cada intento el color de las letras cambia \r\n"
				    + "para mostrar qu� tan cerca est�s de acertar la palabra.\r\n"
				    + "\r\n"
				    + "Ejemplos\r\n"
				    + "La letra R est� en la palabra y en la posici�n correcta.\r\n"
				    + "La letra C est� en la palabra pero en la posici�n incorrecta.\r\n"
				    + "La letra O no est� en la palabra.\r\n"
				    + "Puede haber letras repetidas y en ese caso las pistas son \r\n"
				    + "independientes para cada letra y tienen prioridad.");
			
		}
	}
	
	

	
	
	
}