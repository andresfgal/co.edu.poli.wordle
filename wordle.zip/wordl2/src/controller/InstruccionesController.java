package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class InstruccionesController {
	
	private MatrizController controllerMatriz;
	private Stage stage;

    @FXML
    private AnchorPane anchor;

    @FXML
    private Pane pane2;

    @FXML
    private TextArea instrucciones;

    @FXML
    private Button botonregresar;

    @FXML
    void regresar(ActionEvent event) {
    	
		MatrizController newframe = new MatrizController ();
		
		newframe.setVisible(true);
		
		this.dispose ();

    }

	private void dispose() {
		// TODO Auto-generated method stub
		
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
